#include "array.c"

void merge(int[], int, int[], int, int[]);
void print(char[], int[], int);
int isEqual(int[], int[], int);
//void shiftLeft(int[N], int, int);